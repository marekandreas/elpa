#!/usr/bin/perl -w

use strict;
#use File::Spec;


# first open the template file

my $license_file="LICENSE_template.txt";

open LICENSE, "<", $license_file or die "Could not open file '$license_file': $!";

my @LICENSE_TEXT=<LICENSE>;
#foreach my $line (@LICENCE_TEXT){ 
#    print $line;
#}


close LICENSE;

foreach my $file (@ARGV) {
    print "processig $file \n";
    open my $fd, "+<", $file or die "Could not open file '$file': $!";

    my @source_text =<$fd>;

#foreach my $line (@source_text){ 
#    print $line;
#}

# descriminate to filetypes

    my @LICENSE_WRITE = @LICENSE_TEXT;

    if ($file =~ /Makefile/) {

	# do not replace anyting

	@LICENSE_WRITE = @LICENSE_TEXT;

   
    }

    if (($file =~ /f90/) || ($file =~ /F90/)) {
	
	print "$file is a Fortran file \n";

	# search and replace # with !
	@LICENSE_WRITE = @LICENSE_TEXT;
	foreach(@LICENSE_WRITE) {s/#/!/g;}

    }


    if (($file =~ /\.c/) || ($file =~ /\.cpp/)) {
	
	print "$file is a C / C++ file \n";

	# search and replace # with !
	@LICENSE_WRITE = @LICENSE_TEXT;
	foreach(@LICENSE_WRITE) {s/#/\/\//g;}

    }


    open NEWFILE, ">", $file . "new";
    print NEWFILE @LICENSE_WRITE;
    print NEWFILE @source_text;
    close NEWFILE;
    close $fd;
}
    

